/**
 * Arun S — Developer Portfolio Interactive Enhancements (Vanilla JS)
 * Handles persistent Dark/Light theme switching, accessible mobile menu drawer,
 * filter live announcements, modal focus trapping, and WCAG form validation.
 */

(function () {
  'use strict';

  /* ------------------------------------------------------------------------
     0. Persistent Dark / Light Mode Theme Switcher
     ------------------------------------------------------------------------ */
  const THEME_STORAGE_KEY = 'arun-portfolio-theme';
  const themeToggle = document.getElementById('theme-toggle');
  const rootEl = document.documentElement;

  const sunIconSvg =
    '<svg class="theme-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>';

  const moonIconSvg =
    '<svg class="theme-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>';

  const syncThemeButton = function (activeTheme) {
    if (!themeToggle) return;
    const isDark = activeTheme === 'dark';
    themeToggle.setAttribute('aria-pressed', isDark ? 'true' : 'false');
    themeToggle.setAttribute(
      'aria-label',
      isDark ? 'Switch to light mode' : 'Switch to dark mode'
    );
    themeToggle.innerHTML =
      (isDark ? sunIconSvg : moonIconSvg) +
      '<span class="theme-toggle-text">' +
      (isDark ? 'Light' : 'Dark') +
      '</span>';
  };

  const applyTheme = function (theme, persist) {
    rootEl.setAttribute('data-theme', theme);
    syncThemeButton(theme);
    if (persist) {
      try {
        localStorage.setItem(THEME_STORAGE_KEY, theme);
      } catch (e) {
        // Ignore storage restrictions in private browsing modes
      }
    }
  };

  const initialTheme = rootEl.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  syncThemeButton(initialTheme);

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      const current = rootEl.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next, true);
    });
  }

  /* ------------------------------------------------------------------------
     1. Accessible Mobile Navigation Drawer
     ------------------------------------------------------------------------ */
  const menuToggle = document.getElementById('mobile-menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');

  if (menuToggle && mobileNav) {
    const closeMenu = function () {
      menuToggle.setAttribute('aria-expanded', 'false');
      menuToggle.setAttribute('aria-label', 'Open navigation menu');
      menuToggle.textContent = 'Menu';
      mobileNav.hidden = true;
    };

    const openMenu = function () {
      menuToggle.setAttribute('aria-expanded', 'true');
      menuToggle.setAttribute('aria-label', 'Close navigation menu');
      menuToggle.textContent = 'Close';
      mobileNav.hidden = false;
      const firstLink = mobileNav.querySelector('a');
      if (firstLink) {
        firstLink.focus();
      }
    };

    menuToggle.addEventListener('click', function () {
      const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
      if (isExpanded) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && !mobileNav.hidden) {
        closeMenu();
        menuToggle.focus();
      }
    });
  }

  /* ------------------------------------------------------------------------
     2. Accessible Filter Bar (Projects & Certifications)
     ------------------------------------------------------------------------ */
  const filterButtons = document.querySelectorAll('[data-filter-btn]');
  const filterItems = document.querySelectorAll('[data-filter-category]');
  const filterStatus = document.getElementById('filter-live-status');

  if (filterButtons.length > 0 && filterItems.length > 0) {
    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        const selectedCategory = button.getAttribute('data-filter-btn');

        filterButtons.forEach(function (btn) {
          btn.setAttribute('aria-pressed', btn === button ? 'true' : 'false');
        });

        let visibleCount = 0;
        filterItems.forEach(function (item) {
          const itemCategories = (item.getAttribute('data-filter-category') || '').split(' ');
          const shouldShow =
            selectedCategory === 'all' || itemCategories.includes(selectedCategory);
          item.hidden = !shouldShow;
          if (shouldShow) {
            visibleCount += 1;
          }
        });

        if (filterStatus) {
          const label = button.textContent ? button.textContent.trim() : selectedCategory;
          filterStatus.textContent =
            'Showing ' +
            visibleCount +
            ' ' +
            (visibleCount === 1 ? 'item' : 'items') +
            ' in ' +
            label +
            '.';
        }
      });
    });
  }

  /* ------------------------------------------------------------------------
     3. Accessible Modal Dialog for Project Specifications (projects.html)
     ------------------------------------------------------------------------ */
  const modalBackdrop = document.getElementById('project-modal-backdrop');
  const modalTitle = document.getElementById('modal-project-title');
  const modalMeta = document.getElementById('modal-project-meta');
  const modalSummary = document.getElementById('modal-project-summary');
  const modalHighlights = document.getElementById('modal-project-highlights');
  const modalCloseBtn = document.getElementById('modal-close-btn');
  const modalTriggers = document.querySelectorAll('[data-open-project]');

  let lastFocusedTrigger = null;

  const projectDetailsMap = {
    'wcag-audit': {
      title: 'WCAG 2.1 Semantic Web Audit Checklist',
      meta: 'HTML5 · ARIA · Vanilla JavaScript · Academic Project',
      summary:
        'A lightweight browser-ready checklist and landmark inspector designed for second-year computer science students learning semantic HTML5 structure, heading hierarchy verification, and keyboard focus auditing.',
      highlights: [
        'Validates presence of single <main>, landmark regions, and skip-to-content links.',
        'Checks sequential heading order (H1 through H4) without skipped levels.',
        'Supports full keyboard operation with zero mouse dependency.'
      ]
    },
    'eec-portal': {
      title: 'Easwari CSE Study & Timetable Hub',
      meta: 'HTML5 · CSS Grid · Responsive Layout · 2026',
      summary:
        'A clean academic timetable and subject resource hub tailored for 2nd-year CSE students at Easwari Engineering College, prioritizing mobile readability and high-contrast typography.',
      highlights: [
        'Structured using semantic <table> captions, <th scope="col">, and <th scope="row">.',
        'Responsive card fallback on narrow screens with 44px minimum touch targets.',
        'Zero external CSS frameworks; built entirely with CSS Grid and custom properties.'
      ]
    },
    'algo-studio': {
      title: 'Data Structures & Graph Traversal Visualizer',
      meta: 'HTML5 Canvas · Vanilla JS · CSE Core',
      summary:
        'An accessible educational visualization tool demonstrating Breadth-First Search, Depth-First Search, and Binary Search Tree insertions paired with live screen-reader step announcements.',
      highlights: [
        'Uses an aria-live="polite" log alongside visual node transitions.',
        'Respects prefers-reduced-motion by stepping instantly when enabled.',
        'Provides keyboard shortcuts (Space to step, R to reset) documented on screen.'
      ]
    }
  };

  if (modalBackdrop && modalCloseBtn && modalTriggers.length > 0) {
    const closeModal = function () {
      modalBackdrop.hidden = true;
      document.body.style.overflow = '';
      if (lastFocusedTrigger) {
        lastFocusedTrigger.focus();
      }
    };

    modalTriggers.forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        const key = trigger.getAttribute('data-open-project');
        const details = projectDetailsMap[key];
        if (!details) return;

        lastFocusedTrigger = trigger;
        modalTitle.textContent = details.title;
        modalMeta.textContent = details.meta;
        modalSummary.textContent = details.summary;
        modalHighlights.innerHTML = '';

        details.highlights.forEach(function (point) {
          const li = document.createElement('li');
          li.textContent = point;
          modalHighlights.appendChild(li);
        });

        modalBackdrop.hidden = false;
        document.body.style.overflow = 'hidden';
        modalCloseBtn.focus();
      });
    });

    modalCloseBtn.addEventListener('click', closeModal);

    modalBackdrop.addEventListener('click', function (event) {
      if (event.target === modalBackdrop) {
        closeModal();
      }
    });

    document.addEventListener('keydown', function (event) {
      if (modalBackdrop.hidden) return;

      if (event.key === 'Escape') {
        closeModal();
        return;
      }

      if (event.key === 'Tab') {
        const focusable = modalBackdrop.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;

        const firstEl = focusable[0];
        const lastEl = focusable[focusable.length - 1];

        if (event.shiftKey && document.activeElement === firstEl) {
          event.preventDefault();
          lastEl.focus();
        } else if (!event.shiftKey && document.activeElement === lastEl) {
          event.preventDefault();
          firstEl.focus();
        }
      }
    });
  }

  /* ------------------------------------------------------------------------
     4. Accessible Contact Form Validation (contact.html)
     ------------------------------------------------------------------------ */
  const contactForm = document.getElementById('contact-form');

  if (contactForm) {
    const errorBanner = document.getElementById('form-error-summary');
    const errorList = document.getElementById('form-error-list');
    const successBanner = document.getElementById('form-success-banner');

    const fields = {
      name: {
        input: document.getElementById('contact-name'),
        error: document.getElementById('error-name'),
        validate: function (val) {
          if (!val.trim()) return 'Please enter your full name.';
          if (val.trim().length < 2) return 'Name must be at least 2 characters long.';
          return '';
        }
      },
      email: {
        input: document.getElementById('contact-email'),
        error: document.getElementById('error-email'),
        validate: function (val) {
          if (!val.trim()) return 'Please enter your email address.';
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(val.trim())) {
            return 'Please enter a valid email address (for example, name@example.com).';
          }
          return '';
        }
      },
      subject: {
        input: document.getElementById('contact-subject'),
        error: document.getElementById('error-subject'),
        validate: function (val) {
          if (!val.trim()) return 'Please enter a subject for your message.';
          if (val.trim().length < 4) return 'Subject must be at least 4 characters long.';
          return '';
        }
      },
      message: {
        input: document.getElementById('contact-message'),
        error: document.getElementById('error-message'),
        validate: function (val) {
          if (!val.trim()) return 'Please enter your message.';
          if (val.trim().length < 15) {
            return 'Message must be at least 15 characters long so I can understand your inquiry.';
          }
          return '';
        }
      }
    };

    const validateSingleField = function (key) {
      const field = fields[key];
      const errorMsg = field.validate(field.input.value);
      if (errorMsg) {
        field.input.setAttribute('aria-invalid', 'true');
        field.error.textContent = 'Error: ' + errorMsg;
        field.error.hidden = false;
      } else {
        field.input.removeAttribute('aria-invalid');
        field.error.textContent = '';
        field.error.hidden = true;
      }
      return errorMsg;
    };

    Object.keys(fields).forEach(function (key) {
      fields[key].input.addEventListener('blur', function () {
        validateSingleField(key);
      });
    });

    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();

      if (successBanner) {
        successBanner.hidden = true;
      }

      const errors = [];
      let firstInvalidInput = null;

      Object.keys(fields).forEach(function (key) {
        const msg = validateSingleField(key);
        if (msg) {
          errors.push({
            id: fields[key].input.id,
            message: msg
          });
          if (!firstInvalidInput) {
            firstInvalidInput = fields[key].input;
          }
        }
      });

      if (errors.length > 0) {
        errorList.innerHTML = '';
        errors.forEach(function (err) {
          const li = document.createElement('li');
          const link = document.createElement('a');
          link.href = '#' + err.id;
          link.textContent = err.message;
          link.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.getElementById(err.id);
            if (target) target.focus();
          });
          li.appendChild(link);
          errorList.appendChild(li);
        });

        errorBanner.hidden = false;
        errorBanner.focus();
        return;
      }

      errorBanner.hidden = true;
      const senderName = fields.name.input.value.trim();
      if (successBanner) {
        const successText = document.getElementById('form-success-text');
        if (successText) {
          successText.textContent =
            'Thank you, ' +
            senderName +
            '. Your message has been validated and prepared. You may also reach me directly at aruns1422008@gmail.com.';
        }
        successBanner.hidden = false;
        successBanner.focus();
      }
      contactForm.reset();
    });
  }
})();
